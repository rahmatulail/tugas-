<?php
    $nama   = "the prediksi";
    $no     = 4;
    $desimal = 0.5;

    echo "<b>Pengguna echo</b><br>";
    echo "Nama Kelompok : ".$nama."<br>";
    echo "No    : ".$no."<br>";
    echo "desimal   : ".$desimal."<br>";

    print "<b>Penggunaan print</b><br>";
    print "Nama Kelompok : ".$nama."<br>";
    print "No    : ".$no."<br>";
    print "desimal   : ".$desimal."<br>";

?>