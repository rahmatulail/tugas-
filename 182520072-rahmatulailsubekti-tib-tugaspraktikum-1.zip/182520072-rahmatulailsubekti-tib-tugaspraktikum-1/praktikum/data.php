<?php
 echo "Menggunakan perintah echo <br>";
 echo "Selamat Datang di Matakuliah Praktikum pemograman Framework <br>";
 echo "................................. <br>";
 print "menggunakan perintah print <br>";
 print "Selamaat Datang di Matakuliah praktikum Pemograman Framework <br>";
?>