<!DOCTYPE html>
<html>
    <head>
        <title> error conect</title>
     <style>
         .card{
             
             max-width: 350px;
             text-align: center;
             color: #fff;
             border: 10px solid;
             height: 400px;
             width: 700px;
             border-color: grey;
             background: black;
         } 
        </style>
    <head>
        <body>
        <div class= "card">
            <?php
           
           $nama_barang = "beat black";
           $kode_barang = "5231xxx";
           $spesifikasi_barang = "barang baru dan mulus";
           $harga = "Rp 14.000.000,-";
           $ekspedisi = "3 hari";
           ?>  
            
        <h2>Data Barang</h2>
        <img src="honda.JPG" height= "90" width="80">
        
            <p>Nama Barang     : <?php echo $nama_barang;?> </p>
            <p>Kode Barang   : <?php echo $kode_barang;?> </p>
            <p>Spesifikasi Barang    : <?php echo $spesifikasi_barang;?> </p>
            <p>Harga Barang     : <?php echo $harga;?></p>
            <p>Ekspedisi Pengiriman     : <?php echo $ekspedisi;?></p>

        </div>
        </body>
</html>
